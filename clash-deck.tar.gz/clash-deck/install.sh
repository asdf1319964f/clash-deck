#!/bin/bash
# ============================================================
# Clash-Deck Installer for Steam Deck
# ============================================================

APPIMAGE_PATH="$(readlink -f "$1")"
INSTALL_DIR="$HOME/.local/share/clash-deck"
DESKTOP_DIR="$HOME/.local/share/applications"
AUTOSTART_DIR="$HOME/.config/autostart"
BIN_LINK="$HOME/.local/bin/clash-deck"

# Colors
G='\033[0;32m' Y='\033[1;33m' R='\033[0;31m' N='\033[0m' W='\033[1;37m'

echo ""
echo -e "${W}╔═══════════════════════════════════════╗${N}"
echo -e "${W}║      Clash-Deck Installer 🎮           ║${N}"
echo -e "${W}╚═══════════════════════════════════════╝${N}"
echo ""

if [ -z "$APPIMAGE_PATH" ] || [ ! -f "$APPIMAGE_PATH" ]; then
    echo -e "${R}Usage: ./install.sh Clash-Deck-x86_64.AppImage${N}"
    exit 1
fi

# ── Create directories ───────────────────────────────────────
echo -e "${Y}[1/5]${N} Creating directories..."
mkdir -p "$INSTALL_DIR" "$DESKTOP_DIR" "$AUTOSTART_DIR" "$HOME/.local/bin"

# ── Copy AppImage ────────────────────────────────────────────
echo -e "${Y}[2/5]${N} Installing AppImage..."
cp "$APPIMAGE_PATH" "$INSTALL_DIR/clash-deck.AppImage"
chmod +x "$INSTALL_DIR/clash-deck.AppImage"

# Create bin symlink
ln -sf "$INSTALL_DIR/clash-deck.AppImage" "$BIN_LINK"
echo -e "  ${G}✓${N} Installed to $INSTALL_DIR"

# ── Desktop entry ────────────────────────────────────────────
echo -e "${Y}[3/5]${N} Creating desktop entry..."
cat > "$DESKTOP_DIR/clash-deck.desktop" << EOF
[Desktop Entry]
Type=Application
Name=Clash-Deck
Comment=Global SOCKS5 Proxy for Steam Deck
Exec=$INSTALL_DIR/clash-deck.AppImage
Icon=$INSTALL_DIR/clash-deck.AppImage
Categories=Network;
Terminal=false
StartupNotify=true
EOF
echo -e "  ${G}✓${N} Desktop entry created"

# ── Autostart (optional) ─────────────────────────────────────
echo ""
read -p "  Auto-start proxy on login? [y/N]: " AUTOSTART
if [[ "$AUTOSTART" == "y" || "$AUTOSTART" == "Y" ]]; then
    cat > "$AUTOSTART_DIR/clash-deck.desktop" << EOF
[Desktop Entry]
Type=Application
Name=Clash-Deck Autostart
Exec=$INSTALL_DIR/clash-deck.AppImage start
Hidden=false
NoDisplay=true
X-GNOME-Autostart-enabled=true
EOF
    echo -e "  ${G}✓${N} Autostart configured"
fi

# ── systemd user service (optional) ─────────────────────────
echo ""
read -p "  Install as systemd user service? [y/N]: " SYSTEMD
if [[ "$SYSTEMD" == "y" || "$SYSTEMD" == "Y" ]]; then
    SYSTEMD_DIR="$HOME/.config/systemd/user"
    mkdir -p "$SYSTEMD_DIR"
    cat > "$SYSTEMD_DIR/clash-deck.service" << EOF
[Unit]
Description=Clash-Deck Global Proxy
After=network.target

[Service]
Type=forking
ExecStart=$INSTALL_DIR/clash-deck.AppImage start
ExecStop=$INSTALL_DIR/clash-deck.AppImage stop
Restart=on-failure
RestartSec=5

[Install]
WantedBy=default.target
EOF
    systemctl --user daemon-reload
    systemctl --user enable clash-deck.service
    echo -e "  ${G}✓${N} systemd service installed"
    echo -e "  ${Y}Hint:${N} systemctl --user start clash-deck"
fi

# ── PATH setup ───────────────────────────────────────────────
echo -e "${Y}[5/5]${N} Checking PATH..."
if [[ ":$PATH:" != *":$HOME/.local/bin:"* ]]; then
    echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$HOME/.bashrc"
    echo -e "  ${G}✓${N} Added ~/.local/bin to PATH (restart shell)"
fi

echo ""
echo -e "${G}╔═══════════════════════════════════════╗${N}"
echo -e "${G}║      Installation Complete! 🎉         ║${N}"
echo -e "${G}╚═══════════════════════════════════════╝${N}"
echo ""
echo "  Commands:"
echo "    clash-deck            → Open GUI"
echo "    clash-deck start      → Start proxy"
echo "    clash-deck stop       → Stop proxy"
echo "    clash-deck status     → Check status"
echo "    clash-deck config     → Edit config"
echo ""
echo "  Config: ~/.config/clash-deck/config.yaml"
echo ""
echo -e "${Y}⚠  Edit the config file to add your proxy server!${N}"
echo ""
