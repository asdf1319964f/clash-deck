#!/bin/bash
# ============================================================
# Build script for Clash-Deck AppImage
# Run this on a Steam Deck or Linux x86_64 machine
# ============================================================

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
APPDIR="$SCRIPT_DIR/AppDir"
OUTPUT="$SCRIPT_DIR/Clash-Deck-x86_64.AppImage"

echo "================================================"
echo "  Building Clash-Deck AppImage"
echo "================================================"

# ── Step 1: Set permissions ──────────────────────────────────
echo "[1/5] Setting permissions..."
chmod +x "$APPDIR/AppRun"
chmod +x "$APPDIR/usr/bin/clash-deck"
chmod +x "$APPDIR/usr/bin/clash-deck-gui"
chmod +x "$APPDIR/usr/bin/clash-deck-tui"

# ── Step 2: Copy icon ────────────────────────────────────────
echo "[2/5] Setting up icons..."
cp "$APPDIR/clash-deck.svg" \
   "$APPDIR/usr/share/icons/hicolor/256x256/apps/clash-deck.svg" 2>/dev/null || true

# ── Step 3: Download appimagetool ────────────────────────────
echo "[3/5] Checking appimagetool..."
if [ ! -f "/tmp/appimagetool" ]; then
    echo "  Downloading appimagetool..."
    wget -q "https://github.com/AppImage/AppImageKit/releases/download/continuous/appimagetool-x86_64.AppImage" \
        -O /tmp/appimagetool
    chmod +x /tmp/appimagetool
fi

# ── Step 4: Optional - Download clash-core ───────────────────
echo "[4/5] Checking clash-core..."
CLASH_BIN="$APPDIR/usr/bin/clash-core"

if [ ! -f "$CLASH_BIN" ]; then
    echo "  Downloading Clash Meta (mihomo)..."
    ARCH=$(uname -m)
    case $ARCH in
        x86_64) CLASH_ARCH="amd64" ;;
        aarch64) CLASH_ARCH="arm64" ;;
    esac

    wget -q "https://github.com/MetaCubeX/mihomo/releases/latest/download/mihomo-linux-${CLASH_ARCH}.gz" \
        -O /tmp/clash-core.gz

    gunzip -f /tmp/clash-core.gz
    mv /tmp/clash-core "$CLASH_BIN"
    chmod +x "$CLASH_BIN"
    echo "  ✓ clash-core downloaded"
else
    echo "  ✓ clash-core already present"
fi

# ── Step 5: Build AppImage ───────────────────────────────────
echo "[5/5] Building AppImage..."
ARCH=x86_64 /tmp/appimagetool "$APPDIR" "$OUTPUT"

echo ""
echo "================================================"
echo "  ✅ Build complete!"
echo "  Output: $OUTPUT"
echo ""
echo "  Usage:"
echo "    chmod +x $OUTPUT"
echo "    ./$OUTPUT          # Launch GUI"
echo "    ./$OUTPUT start    # Start proxy"
echo "    ./$OUTPUT stop     # Stop proxy"
echo "    ./$OUTPUT status   # Check status"
echo "================================================"
